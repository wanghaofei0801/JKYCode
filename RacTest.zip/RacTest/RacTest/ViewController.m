//
//  ViewController.m
//  RacTest
//
//  Created by wanghaofei on 2016/11/9.
//  Copyright © 2016年 wanghaofei. All rights reserved.
//
#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;
#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    UITextField *textField = ({
        UITextField *textField = [[UITextField alloc] init];
        textField.backgroundColor = [UIColor cyanColor];
        
        textField;
    });
    [self.view addSubview:textField];

    UILabel *label = [[UILabel alloc] init];
    label.text = @"标题:";
    label.font = [UIFont systemFontOfSize:14];
    [self.view addSubview:label];
    
    UIButton *button = [[UIButton alloc] init];
    button.backgroundColor = [UIColor greenColor];
    [self.view addSubview:button];
    
    WS(weakSelf);
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(60, 30));
        make.left.offset(10);
        make.centerY.equalTo(weakSelf.view);
    }];
    
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(label.mas_right).with.offset(10);
        make.right.equalTo(weakSelf.view).with.offset(-10);
        make.centerY.equalTo(label);
    }];

    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(label.mas_bottom).with.offset(20);
        make.size.mas_equalTo(CGSizeMake(100, 100));
        make.centerX.equalTo(self.view);
    }];
    
    

    /**
     textfeild
     */
    [[textField rac_signalForControlEvents:UIControlEventEditingChanged] subscribeNext:^(id x) {
        NSLog(@"x = %@",x);
    }];
    
    //map 使用映射
    [[[textField.rac_textSignal map:^id(NSString * value) {
        
        return @(value.length);
    }]filter:^BOOL(NSNumber *value) {
        return value.integerValue>3;
    }] subscribeNext:^(id x) {
        NSLog(@"输入的单位大于3个了");
    }];
    
    /**
     Button
     */
    button.rac_command = [[RACCommand alloc] initWithSignalBlock:^RACSignal *(id input) {
//        NSLog(@"button= %@",input);
//        [self showAlertView];
//        [self loginSignal];
        [self creatSignal];
        return [RACSignal empty];
    }];
    
    
    /**
     手势
     */
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(UITapGestureRecognizer *tapa) {
        NSLog(@"tapa = %@",tapa);
    }];
     [self.view addGestureRecognizer:tap];
    
    
    /*
     通知 应用进入到后台
     */
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil ] subscribeNext:^(id x) {
        NSLog(@"进入到后台");
    }];
    
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:UIApplicationDidBecomeActiveNotification object:nil ] subscribeNext:^(id x) {
        NSLog(@"进入到应用");
    }];
    
    /*
     延迟去做某件事
     */
    [[RACScheduler mainThreadScheduler] afterDelay:60 schedule:^{
        NSLog(@"已经过去了一分钟");
    }];
    
    /*
     每间隔一段时间就去做一件事
     */
//    [[RACSignal interval:3 onScheduler:[RACScheduler mainThreadScheduler]] subscribeNext:^(id x) {
//        NSLog(@"每3秒调用一次");
//    }];
}

- (void)showAlertView{
    
    /*
     弹框
     */
    UIAlertView *alerview = [[UIAlertView alloc] initWithTitle:@"rac" message:@"哈哈" delegate:self cancelButtonTitle:@"是你" otherButtonTitles:@"就是你", nil];
    [[alerview rac_buttonClickedSignal] subscribeNext:^(id x) {
        NSLog(@"id =%@",x);
        
    }];
    
    [alerview show];
    
}


- (RACSignal *)loginSignal{
    return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
        RACDisposable * schedulerDisposable = [[RACScheduler mainThreadScheduler] afterDelay:2 schedule:^{
            if(arc4random()%10>1){
                [subscriber sendNext:@"Login response"];
                [subscriber sendCompleted];
            }else{
                [subscriber sendError:[NSError errorWithDomain:@"LOGIN_ERROR_DOMAIN" code:444 userInfo:@{}]];
            }
        }];
        return [RACDisposable disposableWithBlock:^{
            
            [schedulerDisposable dispose];
        }];
    }];
}



/**
 创建消息 signal
 */
- (void)creatSignal{
    
    /**
     创建消息 signal
     */
    RACSignal * signl = [[RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
        [subscriber  sendNext:@"123"];
        [subscriber sendNext:@"456"];
        [subscriber sendCompleted];
        return nil;
    }] delay:2];
    
    /**
     订阅信息
     */
    [signl subscribeNext:^(id x) {
        NSLog(@"x = %@",x);
    }];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
